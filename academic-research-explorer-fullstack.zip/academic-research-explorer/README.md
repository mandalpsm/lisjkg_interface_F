# Academic Research Explorer — Full-Stack Project

A bibliographic search, analysis and knowledge-graph explorer for a 27,825-record academic
dataset (100 journals/sources, 43 countries, 2020–2025).

- **Frontend** — a single-page web app (`frontend/index.html`). It runs fully offline from the
  embedded dataset, so opening the file directly also works.
- **Backend** — a small Python server (`backend/server.py`, standard library only, no installs)
  that serves the app and proxies queries to **Neo4j** and **GraphDB** so credentials never reach the browser.
- **Data** — `data/dataset.json` is the dataset exported from the app for reuse or import.
- **Tests** — `tests/test_server.py` covers the proxy, security rules and error handling.

## Project layout

```
academic-research-explorer/
├── frontend/
│   └── index.html          # the web app (self-contained)
├── backend/
│   ├── __init__.py
│   └── server.py           # static server + Neo4j/GraphDB proxies
├── data/
│   └── dataset.json        # 27,825 records exported from the app
├── scripts/
│   └── extract_dataset.py  # re-export data/dataset.json from frontend/index.html
├── tests/
│   └── test_server.py      # unit tests for the backend
├── .env.example            # configuration template
└── README.md
```

## Requirements

- Python 3.9 or newer. No third-party packages are needed.
- For the Neo4j / GraphDB features (optional): a running Neo4j 5+ instance and/or a GraphDB repository.
- A current browser (Chrome, Edge, Firefox or Safari).

## Run it

```bash
cd academic-research-explorer
cp .env.example .env        # optional: edit to match your databases (see below)
export $(grep -v '^#' .env | xargs)   # optional: load the settings
python3 backend/server.py
```

Then open **http://127.0.0.1:8000/**.

Only the search and analysis features need no configuration. To use the Neo4j & GraphDB tab in
**proxy mode**, leave the proxy endpoints at their defaults (`http://localhost:8000/api/neo4j/query`
and `http://localhost:8000/api/graphdb/query`) and select "Backend proxy" in the tab.

Check the server and its configuration (secrets are never shown):

```bash
curl http://127.0.0.1:8000/api/health
```

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `HOST` | `127.0.0.1` | Interface to listen on. Use `0.0.0.0` only behind a firewall or reverse proxy. |
| `PORT` | `8000` | Port for the app and the API. |
| `NEO4J_URL` | `http://localhost:7474` | Neo4j HTTP base URL. |
| `NEO4J_DATABASE` | `neo4j` | Database name. |
| `NEO4J_USER` / `NEO4J_PASSWORD` | empty | Neo4j credentials, kept on the server. |
| `GRAPHDB_REPO_URL` | `http://localhost:7200/repositories/library` | GraphDB SPARQL endpoint. |
| `GRAPHDB_USER` / `GRAPHDB_PASSWORD` | empty | GraphDB credentials, kept on the server. |
| `ALLOW_WRITE_QUERIES` | `0` | Set to `1` to allow write queries (CREATE, MERGE, INSERT, DROP …). Keep `0` unless you need them. |
| `UPSTREAM_TIMEOUT` | `30` | Seconds to wait for Neo4j or GraphDB. |

## API

| Method | Path | Body | Result |
|---|---|---|---|
| GET | `/` | — | The web app. |
| GET | `/api/health` | — | Status and non-secret configuration. |
| POST | `/api/neo4j/query` | `{"query": "<Cypher>", "parameters": {}}` | Neo4j HTTP Query API v2 response (JSON). |
| POST | `/api/graphdb/query` | `{"query": "<SPARQL>"}` | SPARQL JSON results from the repository. |

Errors are JSON: `400` (invalid request), `403` (write query while writes are disabled),
`404` (unknown path), `413` (too large), `502` (Neo4j or GraphDB unreachable).

## Security notes

- Credentials are read from environment variables and sent only to Neo4j/GraphDB, never to the browser.
- Write queries are refused by default. The check is keyword-based, so a write word inside a
  string literal is also refused. Enable writes only when you need them.
- Requests are limited to 1 MB, and static files cannot escape the `frontend/` folder.
- The server is intended for local or trusted-network use. For public deployment, put it behind
  HTTPS (for example a reverse proxy such as nginx or Caddy) and add authentication.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

## Regenerating the dataset export

```bash
python3 scripts/extract_dataset.py
```

## Notes

- The search and knowledge-graph features run in the browser over the embedded dataset.
  The server adds the Neo4j/GraphDB proxies and static hosting; it does not change search results.
- Direct mode in the Neo4j & GraphDB tab talks to the databases from the browser. It needs CORS
  enabled on those databases and is intended for local use only.
