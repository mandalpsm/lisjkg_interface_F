#!/usr/bin/env python3
"""
Academic Research Explorer - backend server (Python standard library only).

Serves the web app from ../frontend and provides the optional server-side
proxies used by the "Neo4j & GraphDB" tab in proxy mode:

  POST /api/neo4j/query    body {"query": "<Cypher>", "parameters": {...}}
                           -> forwarded to the Neo4j HTTP Query API (v2)
  POST /api/graphdb/query  body {"query": "<SPARQL>"}
                           -> forwarded to the GraphDB repository SPARQL endpoint
  GET  /api/health         -> non-secret configuration status

Credentials stay on the server (environment variables) and are never sent to the browser.
Write queries (CREATE, MERGE, DELETE, INSERT, ...) are refused unless ALLOW_WRITE_QUERIES=1.
"""
import base64
import json
import logging
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
log = logging.getLogger("are")

WRITE_PATTERN = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|FOREACH|LOAD\s+CSV|INSERT|CLEAR|LOAD|COPY|MOVE|ADD)\b",
    re.IGNORECASE,
)
MAX_BODY = 1_000_000          # 1 MB request limit
MAX_QUERY_CHARS = 20_000


@dataclass
class Config:
    host: str = "127.0.0.1"
    port: int = 8000
    neo4j_url: str = "http://localhost:7474"
    neo4j_database: str = "neo4j"
    neo4j_user: str = ""
    neo4j_password: str = ""
    graphdb_repo_url: str = "http://localhost:7200/repositories/library"
    graphdb_user: str = ""
    graphdb_password: str = ""
    allow_writes: bool = False
    timeout: float = 30.0
    frontend_dir: Path = field(default_factory=lambda: ROOT / "frontend")

    @classmethod
    def from_env(cls):
        e = os.environ.get
        return cls(
            host=e("HOST", "127.0.0.1"),
            port=int(e("PORT", "8000")),
            neo4j_url=e("NEO4J_URL", "http://localhost:7474"),
            neo4j_database=e("NEO4J_DATABASE", "neo4j"),
            neo4j_user=e("NEO4J_USER", ""),
            neo4j_password=e("NEO4J_PASSWORD", ""),
            graphdb_repo_url=e("GRAPHDB_REPO_URL", "http://localhost:7200/repositories/library"),
            graphdb_user=e("GRAPHDB_USER", ""),
            graphdb_password=e("GRAPHDB_PASSWORD", ""),
            allow_writes=e("ALLOW_WRITE_QUERIES", "0") == "1",
            timeout=float(e("UPSTREAM_TIMEOUT", "30")),
        )


def basic_auth(user, password):
    if not user:
        return {}
    token = base64.b64encode(f"{user}:{password}".encode()).decode()
    return {"Authorization": "Basic " + token}


def build_handler(cfg: Config):
    class Handler(BaseHTTPRequestHandler):
        server_version = "AREServer/1.0"

        # ---------- helpers ----------
        def _send(self, status, body: bytes, ctype, extra=None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass  # client closed the connection early; nothing to do

        def _json(self, status, obj):
            self._send(status, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8",
                       {"Cache-Control": "no-store"})

        def _error(self, status, message):
            self._json(status, {"error": message})

        def log_message(self, fmt, *args):  # quieter default logging
            log.info("%s - %s", self.address_string(), fmt % args)

        # ---------- static files ----------
        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == "/api/health":
                return self._json(200, {
                    "status": "ok",
                    "neo4j": {"url": cfg.neo4j_url, "database": cfg.neo4j_database, "auth": bool(cfg.neo4j_user)},
                    "graphdb": {"repository": cfg.graphdb_repo_url, "auth": bool(cfg.graphdb_user)},
                    "writes_allowed": cfg.allow_writes,
                })
            if path.startswith("/api/"):
                return self._error(404, "Unknown API endpoint")
            rel = "index.html" if path in ("", "/") else path.lstrip("/")
            target = (cfg.frontend_dir / rel).resolve()
            # block path traversal: target must stay inside the frontend folder
            if cfg.frontend_dir.resolve() not in target.parents and target != cfg.frontend_dir.resolve():
                return self._error(404, "Not found")
            if not target.is_file():
                return self._error(404, "Not found")
            ctype = {
                ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
                ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
                ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon",
            }.get(target.suffix.lower(), "application/octet-stream")
            return self._send(200, target.read_bytes(), ctype, {"Cache-Control": "no-cache"})

        # ---------- API proxies ----------
        def _read_query(self):
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > MAX_BODY:
                self._error(413 if length > MAX_BODY else 400, "Request body missing or too large")
                return None
            try:
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self._error(400, "Body must be valid JSON")
                return None
            query = payload.get("query") if isinstance(payload, dict) else None
            if not isinstance(query, str) or not query.strip():
                self._error(400, "Field 'query' is required")
                return None
            if len(query) > MAX_QUERY_CHARS:
                self._error(413, "Query is too long")
                return None
            if not cfg.allow_writes and WRITE_PATTERN.search(query):
                self._error(403, "Write queries are disabled. Set ALLOW_WRITE_QUERIES=1 to enable them.")
                return None
            return payload

        def _forward(self, req: urllib.request.Request):
            try:
                with urllib.request.urlopen(req, timeout=cfg.timeout) as resp:
                    body = resp.read()
                    ctype = resp.headers.get("Content-Type", "application/json")
                    return self._send(resp.status, body, ctype, {"Cache-Control": "no-store"})
            except urllib.error.HTTPError as e:
                detail = e.read()[:500].decode("utf-8", "replace")
                return self._error(e.code, f"Upstream returned {e.code}: {detail}")
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                return self._error(502, f"Upstream unreachable: {getattr(e, 'reason', e)}")

        def do_POST(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == "/api/neo4j/query":
                payload = self._read_query()
                if payload is None:
                    return
                url = f"{cfg.neo4j_url.rstrip('/')}/db/{urllib.parse.quote(cfg.neo4j_database)}/query/v2"
                body = json.dumps({"statement": payload["query"],
                                   "parameters": payload.get("parameters") or {}}).encode("utf-8")
                headers = {"Content-Type": "application/json", "Accept": "application/json",
                           **basic_auth(cfg.neo4j_user, cfg.neo4j_password)}
                return self._forward(urllib.request.Request(url, data=body, headers=headers, method="POST"))

            if path == "/api/graphdb/query":
                payload = self._read_query()
                if payload is None:
                    return
                body = urllib.parse.urlencode({"query": payload["query"]}).encode("utf-8")
                headers = {"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                           "Accept": "application/sparql-results+json",
                           **basic_auth(cfg.graphdb_user, cfg.graphdb_password)}
                return self._forward(urllib.request.Request(cfg.graphdb_repo_url, data=body,
                                                            headers=headers, method="POST"))

            return self._error(404, "Unknown API endpoint")

    return Handler


def build_server(cfg: Config) -> ThreadingHTTPServer:
    return ThreadingHTTPServer((cfg.host, cfg.port), build_handler(cfg))


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cfg = Config.from_env()
    srv = build_server(cfg)
    print(f"Academic Research Explorer running at http://{cfg.host}:{srv.server_address[1]}/")
    print("Press Ctrl+C to stop.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    sys.exit(main())
