#!/usr/bin/env python3
"""Export the dataset embedded in frontend/index.html to data/dataset.json (for reuse, import or analysis)."""
import base64, gzip, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
m = re.search(r'<script id="embeddedData" type="text/plain">(.*?)</script>', html, flags=re.S)
if not m or not m.group(1).strip().startswith("GZB64:"):
    sys.exit("Embedded dataset not found in frontend/index.html")
data = gzip.decompress(base64.b64decode(m.group(1).strip()[6:])).decode("utf-8")
out = ROOT / "data" / "dataset.json"
out.write_text(json.dumps(json.loads(data), ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
print("Wrote", out)
