"""Tests for the backend proxy. Run with:  python -m unittest discover -s tests -v"""
import json
import sys
import threading
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from backend.server import Config, build_server  # noqa: E402


class StubUpstream(BaseHTTPRequestHandler):
    """Pretends to be Neo4j (/db/.../query/v2) and GraphDB (/repositories/...)."""
    seen = []

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n).decode()
        StubUpstream.seen.append({"path": self.path, "body": body,
                                  "auth": self.headers.get("Authorization"),
                                  "ctype": self.headers.get("Content-Type")})
        out = json.dumps({"data": {"fields": ["ok"], "values": [[1]]}}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


def start(server):
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return f"http://127.0.0.1:{server.server_address[1]}"


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.upstream = ThreadingHTTPServer(("127.0.0.1", 0), StubUpstream)
        up = start(cls.upstream)
        base = dict(host="127.0.0.1", port=0, neo4j_url=up, neo4j_database="neo4j",
                    neo4j_user="neo4j", neo4j_password="secret",
                    graphdb_repo_url=up + "/repositories/library",
                    graphdb_user="gd", graphdb_password="gdpw", timeout=5)
        cls.cfg = Config(**base)
        cls.srv = build_server(cls.cfg)
        cls.url = start(cls.srv)

        cls.dead_cfg = Config(**{**base, "neo4j_url": "http://127.0.0.1:9"})
        cls.dead_srv = build_server(cls.dead_cfg)
        cls.dead_url = start(cls.dead_srv)

    @classmethod
    def tearDownClass(cls):
        for s in (cls.srv, cls.dead_srv, cls.upstream):
            s.shutdown(); s.server_close()

    def post(self, path, obj=None, raw=None, base=None):
        data = raw if raw is not None else json.dumps(obj).encode()
        req = urllib.request.Request((base or self.url) + path, data=data,
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def test_index_served(self):
        with urllib.request.urlopen(self.url + "/", timeout=5) as r:
            self.assertEqual(r.status, 200)
            self.assertIn(b"Academic Research Explorer", r.read(200000))

    def test_path_traversal_blocked(self):
        try:
            urllib.request.urlopen(self.url + "/../backend/server.py", timeout=5)
            self.fail("traversal was not blocked")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 404)

    def test_health_hides_secrets(self):
        with urllib.request.urlopen(self.url + "/api/health", timeout=5) as r:
            body = r.read().decode()
        self.assertNotIn("secret", body)
        self.assertNotIn("gdpw", body)

    def test_neo4j_proxy_translates_request_and_adds_auth(self):
        StubUpstream.seen.clear()
        status, body = self.post("/api/neo4j/query", {"query": "MATCH (n) RETURN n LIMIT 5", "parameters": {}})
        self.assertEqual(status, 200)
        self.assertIn('"fields"', body)
        call = StubUpstream.seen[-1]
        self.assertEqual(call["path"], "/db/neo4j/query/v2")
        self.assertEqual(json.loads(call["body"]), {"statement": "MATCH (n) RETURN n LIMIT 5", "parameters": {}})
        self.assertTrue(call["auth"].startswith("Basic "))

    def test_graphdb_proxy_sends_form_query(self):
        StubUpstream.seen.clear()
        status, _ = self.post("/api/graphdb/query", {"query": "SELECT * WHERE { ?s ?p ?o } LIMIT 1"})
        self.assertEqual(status, 200)
        call = StubUpstream.seen[-1]
        self.assertEqual(call["path"], "/repositories/library")
        self.assertIn("application/x-www-form-urlencoded", call["ctype"])
        self.assertIn("query=SELECT", call["body"])

    def test_write_queries_refused_by_default(self):
        StubUpstream.seen.clear()
        for q in ["CREATE (n:Paper {title:'x'})", "MERGE (a:Author {name:'y'})",
                  "INSERT DATA { <a> <b> <c> }", "DROP GRAPH <g>"]:
            status, body = self.post("/api/neo4j/query" if "(" in q else "/api/graphdb/query", {"query": q})
            self.assertEqual(status, 403, q)
            self.assertIn("Write queries are disabled", body)
        self.assertEqual(StubUpstream.seen, [], "write query reached the database")

    def test_validation_errors(self):
        self.assertEqual(self.post("/api/neo4j/query", raw=b"not json")[0], 400)
        self.assertEqual(self.post("/api/neo4j/query", {"query": "   "})[0], 400)
        self.assertEqual(self.post("/api/graphdb/query", {"nope": 1})[0], 400)
        self.assertEqual(self.post("/api/nothing", {"query": "RETURN 1"})[0], 404)

    def test_upstream_down_returns_502(self):
        status, body = self.post("/api/neo4j/query", {"query": "RETURN 1"}, base=self.dead_url)
        self.assertEqual(status, 502)
        self.assertIn("unreachable", body)


if __name__ == "__main__":
    unittest.main()
